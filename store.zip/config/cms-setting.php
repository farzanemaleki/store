<?php

return [
    'url'=>'/product_image',
    'url_product_category_image'=>'/product_category_image',
    'url_blog'=>'/blog_image',
    'url_blog_category_image'=>'/blog_category_image',
    'url_logo' => '/logo',
    'url_elecSymbol' => '/elecSymbol',
    'url_socialMedia' => '/socialMedia',
    'url_partner' => '/partner'

];
